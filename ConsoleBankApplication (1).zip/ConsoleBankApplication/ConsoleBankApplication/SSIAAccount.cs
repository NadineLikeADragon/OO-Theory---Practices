﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankApplication
{
    class SSIAAccount : Deposit
    {

        public SSIAAccount() { }
        public SSIAAccount(double balance, string id, double intr)
            : base(balance, id, intr)
        {

        }

        public SSIAAccount(string id, double intr)
            : base(id, intr)
        {

        }
        public override void Withdraw(double amount)
        {
            Console.Write("not allowed on this account type");

        }

        public override void Lodge(double amount)
        {
            balance += 1.25 * amount;
        }

        public override string ShowDetails()
        {
            return String.Format("SSIAAccount id:{0}   Balance:{1,10}  Interest Rate{2,10}\n", id, balance.ToString("F2"), IntRate.ToString("F2"));

        }
    }
}
