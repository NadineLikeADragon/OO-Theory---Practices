﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankApplication
{
   
        public abstract class Account
        {
            public double balance { get; set; }
            public string id { get; set; }

            public Account(double balance, string id)
            {
                this.balance = balance;
                this.id = id;
            }

            public Account()
            {
                balance = 0;
                id = "";
            }

            public Account(string id)
            {
                balance = 0;
                this.id = id;
            }


            public virtual void Lodge(double amount)
            {
                balance += amount;
            }
            public abstract void Withdraw(double amount);
            public abstract string ShowDetails();
        }
    
}
