﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankApplication
{
    class Deposit : Account
    {
        public double IntRate { get; set; }

        public Deposit()
            : base()
        {
            IntRate = 0;
        }
        public Deposit(string id, double intr)
            : base(id)
        {
            IntRate = intr;
        }
        public Deposit(double balance, string id, double intr)
            : base(balance, id)
        {
            IntRate = intr;
        }

        public override void Withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance -= amount;
            }
            else
            {
                Console.Write("not allowed as amount > balance");
            }
        }
        public override string ShowDetails()
        {
            return String.Format("Deposit Account id:{0}   Balance:{1,10}  Interest Rate{2,10}\n", id, balance.ToString("F2"), IntRate.ToString("F2"));

        }

        public void AddQtrInterest()
        {
            balance = balance + (balance * IntRate / 100 / 4);

        }
    }
}
