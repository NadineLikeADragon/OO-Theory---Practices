﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankApplication
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

   
        class BankSystem
        {

            public static void Main(String[] args)
            {
                // create a collection to hold accountd in

                List<Account> customersAccounts = new List<Account>();



                Console.WriteLine("** the bank system **");


                int option = 0;
                do
                {
                    Console.WriteLine("1.   Create account");
                    Console.WriteLine("2.  Show All Account Details");
                    Console.WriteLine("3.  Lodge.");
                    Console.WriteLine("4.  Withdrawal.");
                    Console.WriteLine("5.  Maintance: Run quarter interest rate");
                    Console.WriteLine("6.  Exit");
                    option = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine(option);
                    switch (option)
                    {
                        case 1:
                            {
                                createAccounts(customersAccounts);
                                //Console.WriteLine("accounts" + customersAccounts.Count);
                                break;
                            }
                        case 2:
                            {
                                displayAccounts(customersAccounts);
                                break;
                            }
                        case 3:
                            {
                                Lodge(customersAccounts);
                                break;
                            }
                        case 4:
                            {
                                WithDraw(customersAccounts);
                                break;
                            }

                        case 5:
                            {
                                MaintanceRun(customersAccounts);
                                break;
                            }
                        case 6:
                            break;

                        default:
                            {
                                Console.WriteLine("option not implemented ");
                                break;
                            }
                    }
                } while (option != 6);
            }



            public static void MaintanceRun(List<Account> cAccounts)
            {

                foreach (Account a in cAccounts)
                {
                    bool isDeposit = (a is Deposit);
                    if (isDeposit)
                    {

                        Deposit d = (Deposit)a;
                        d.AddQtrInterest();
                        d.ShowDetails();
                    }
                }



            }
            public static void createAccounts(List<Account> cAccounts)
            {
                Deposit d1 = new Deposit(1000, "1001", 5);
                Deposit d2 = new Deposit(500, "1002", 3);
                Deposit d3 = new Deposit(200, "1003", 4);

                cAccounts.Add(d1);
                cAccounts.Add(d2);
                cAccounts.Add(d3);

                SSIAAccount SS1 = new SSIAAccount(100, "1004", 10);
                SSIAAccount SS2 = new SSIAAccount(1000, "1005", 10);
                SSIAAccount SS3 = new SSIAAccount(4000, "1008", 5);

                cAccounts.Add(SS1);
                cAccounts.Add(SS2);
                cAccounts.Add(SS3);

                CurrentAccount ca1 = new CurrentAccount(100, "1009", 300);
                CurrentAccount ca2 = new CurrentAccount(50, "1010", 100);
                CurrentAccount ca3 = new CurrentAccount(800, "1011", 400);

                cAccounts.Add(ca1);
                cAccounts.Add(ca2);
                cAccounts.Add(ca3);
                Console.WriteLine("accounts created on the system");


            }

            public static void displayAccounts(List<Account> cAccounts)
            {
                foreach (Account a in cAccounts)
                {
                    String s = a.ShowDetails();
                    Console.WriteLine(s);
                }

            }


            public static void Lodge(List<Account> cAccounts)
            {
                Console.WriteLine("process logdement - Enter in account id");
                String id = Console.ReadLine();
                Console.WriteLine("process logdement - Enter amount");
                double amount = Convert.ToDouble(Console.ReadLine());

                Account fa = findAccount(cAccounts, id);
                if (fa != null)
                {
                    fa.Lodge(amount);
                }
                else
                {
                    Console.WriteLine("Error can't kind account");
                }

            }

            public static void WithDraw(List<Account> cAccounts)
            {
                Console.WriteLine("process withdrawal - Enter in account id");
                String id = Console.ReadLine();
                Console.WriteLine("process withdrawal - Enter amount");
                double amount = Convert.ToDouble(Console.ReadLine());

                Account fa = findAccount(cAccounts, id);
                if (fa != null)
                {
                    fa.Withdraw(amount);
                }
                else
                {
                    Console.WriteLine("Error can't kind account");
                }

            }

            public static Account findAccount(List<Account> cAccounts, string id)
            {
                Account x = null;
                foreach (Account a in cAccounts)
                {
                    if (a.id.Equals(id))
                    {
                        return a;
                    }
                }

                return x;
            }

        }
    

}
