﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankApplication
{
    public class CurrentAccount : Account
    {
        public double creditLimit { get; set; }

        public CurrentAccount(string id): base(id)
        {
            creditLimit = 0;
        }

        public CurrentAccount()
            : base()
        {
            creditLimit = 0; ;
        }

        public CurrentAccount(double balance, string id, double cLimit)
            : base(balance, id)
        {
            creditLimit = cLimit;
        }

        public override void Withdraw(double amount)
        {
            if (amount <= balance + creditLimit)
                balance -= amount;
            else
                Console.WriteLine("Insufficient funds");
        }

        public override string ShowDetails()
        {
            return String.Format("Current Account id:{0}   Balance:{1,10}  CreditLimit{2,10}\n", id, balance.ToString("F2"), creditLimit.ToString("F2"));
        }
    }
}
